#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IPA Browser - servizio che gira SULL'iPad (jailbreak, come root).
Compatibile con Python 2.7 (quello di Cydia) e Python 3. Solo libreria standard.

La pagina in Safari (http://127.0.0.1:8026/) e solo l'interfaccia: questo servizio
  - scarica l'indice (curl) e le icone,
  - scarica l'IPA scelta da archive.org (curl, con ripresa),
  - la installa con ipainstaller o appinst,
  - tiene un log in /var/mobile/Library/IPABrowser/ipabrowser.log

Sicurezza: ascolta solo su 127.0.0.1, controlla Host/Origin, le azioni richiedono
l'intestazione X-IPAB e accettano solo il NUMERO di un'app dell'indice (mai un URL).
"""
from __future__ import print_function
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
import traceback
import zipfile

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import urlsplit, quote
    from queue import Queue
except ImportError:  # Python 2
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import urlsplit
    from urllib import quote
    from Queue import Queue

VERSION = '1.0'
HERE = os.path.dirname(os.path.abspath(__file__))
UA = 'Mozilla/5.0 (iPad; CPU OS 9_3 like Mac OS X) IPABrowser/' + VERSION
PY2 = sys.version_info[0] == 2

HOME = os.environ.get('IPAB_HOME', '/var/mobile/Library/IPABrowser')
CFG = {
    'port': int(os.environ.get('IPAB_PORT', '8026')),
    'bind': '127.0.0.1',
    'upstream': os.environ.get('IPAB_UPSTREAM', 'https://ipaarchive.github.io/data/'),
    'www': os.environ.get('IPAB_WWW', HERE),
    'curl': os.environ.get('IPAB_CURL', ''),
    'installer': os.environ.get('IPAB_INSTALLER', ''),
    'installer_args': [],
    'keep_ipa': False,
    'insecure_tls': False,
    'index_max_age_days': 7,
    'connect_timeout': int(os.environ.get('IPAB_CONNECT_TIMEOUT', '20')),
}
LOCK = threading.RLock()
QUEUE = Queue()
JOBS = {}
INDEX = {'ready': False, 'bytes': 0, 'error': '', 'busy': False, 'age': None}
ICON_SLOTS = threading.Semaphore(3)
NOICON = set()


# ----------------------------------------------------------------------------
# utilita'
# ----------------------------------------------------------------------------
def u(s):
    if isinstance(s, bytes):
        return s.decode('utf-8', 'replace')
    return s


def b(s):
    if not isinstance(s, bytes):
        return s.encode('utf-8', 'replace')
    return s


def T(x):
    """Testo unicode in Python 2 e 3 (str() su stringhe non ASCII crasha in Python 2)."""
    if isinstance(x, bytes):
        return x.decode('utf-8', 'replace')
    return x if isinstance(x, type(u'')) else type(u'')(x)


def log(msg):
    line = '[%s] %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), u(msg))
    try:
        print(line.encode('utf-8') if PY2 else line)
        sys.stdout.flush()
    except Exception:
        pass
    try:
        if not os.path.isdir(HOME):
            os.makedirs(HOME)
        p = os.path.join(HOME, 'ipabrowser.log')
        if os.path.exists(p) and os.path.getsize(p) > 1048576:
            os.rename(p, p + '.1')
        with open(p, 'ab') as f:
            f.write((line + '\n').encode('utf-8'))
    except Exception:
        pass


def replace(src, dst):
    try:
        os.replace(src, dst)
    except AttributeError:
        os.rename(src, dst)


def which(name, extra=()):
    for d in list(extra) + os.environ.get('PATH', '').split(':') + ['/usr/bin', '/usr/local/bin', '/bin', '/usr/sbin', '/sbin', '/var/jb/usr/bin']:
        p = os.path.join(d, name)
        if d and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return ''


def free_bytes(path):
    fake = os.environ.get('IPAB_FAKE_FREE_MB')
    if fake:
        return int(float(fake) * 1048576)
    try:
        st = os.statvfs(path)
        return st.f_bavail * st.f_frsize
    except Exception:
        return 0


def encode_path(p):
    # come encodeURI() del sito originale: i nomi dell'indice sono nomi grezzi, quindi anche '%' va codificato
    return u(quote(b(p), safe=b";,/:@&=+$!*'()"))


def human(n):
    n = float(n)
    for unit in ('B', 'kB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return '%.1f %s' % (n, unit)
        n /= 1024.0


def load_config():
    p = os.path.join(HOME, 'config.json')
    if os.path.isfile(p):
        try:
            with open(p, 'rb') as f:
                cfg = json.loads(u(f.read()))
            for k, v in cfg.items():
                if k in CFG and not (k in ('curl', 'installer') and os.environ.get('IPAB_' + k.upper())):
                    CFG[k] = v
            log('config.json caricato: %s' % json.dumps(cfg))
        except Exception as e:
            log('ATTENZIONE: config.json non valido: %r' % (e,))
    if not CFG['curl']:
        CFG['curl'] = which('curl')
    if not CFG['installer']:
        CFG['installer'] = which('ipainstaller') or which('appinst')
    CFG['upstream'] = CFG['upstream'] if CFG['upstream'].endswith('/') else CFG['upstream'] + '/'


def curl_cmd(url, out=None, head=False, resume=False, timeout=None):
    cmd = [CFG['curl'], '-sS', '-L', '--connect-timeout', str(CFG['connect_timeout']), '-A', UA]
    if CFG['insecure_tls']:
        cmd.append('-k')
    if head:
        cmd += ['-I']
    else:
        cmd += ['-f', '--retry', '2', '--retry-delay', '3', '--speed-limit', '1', '--speed-time', '60']
        if resume:
            cmd += ['-C', '-']
        if out:
            cmd += ['-o', out]
    if timeout:
        cmd += ['--max-time', str(timeout)]
    cmd.append(url)
    return cmd


CURL_HINTS = {
    6: 'impossibile risolvere il nome del server (niente rete o DNS?)',
    7: 'impossibile connettersi al server (niente rete?)',
    22: 'il server ha risposto con un errore (il file potrebbe non esistere piu)',
    28: 'timeout della rete',
    33: 'il server non supporta la ripresa',
    35: 'errore TLS: la versione di curl/OpenSSL dell\'iPad e troppo vecchia per questo sito',
    51: 'certificato del server non verificabile',
    56: 'connessione interrotta durante il download',
    58: 'problema col certificato locale',
    60: 'certificato non attendibile: installa il pacchetto "ca-certificates" da Cydia (oppure "insecure_tls": true in config.json, sconsigliato)',
}


def curl_error(rc, err):
    hint = CURL_HINTS.get(rc, 'errore sconosciuto')
    m = re.search(r'error: (\d+)', err or '')
    if rc == 22 and m:
        hint = 'HTTP %s: %s' % (m.group(1), 'il file non esiste piu su archive.org' if m.group(1) in ('404', '410') else 'il server rifiuta la richiesta')
    return 'curl codice %d: %s' % (rc, hint)


def run_curl(url, out, resume=False, on_poll=None, cancelled=None, max_time=None):
    """Esegue curl, restituisce (rc, stderr). on_poll() ogni 0.5s; cancelled() -> True per interrompere."""
    errf = out + '.err'
    with open(errf, 'wb') as ef:
        p = subprocess.Popen(curl_cmd(url, out=out, resume=resume, timeout=max_time), stdout=subprocess.PIPE, stderr=ef)
        while p.poll() is None:
            if cancelled and cancelled():
                p.terminate()
                time.sleep(0.3)
                if p.poll() is None:
                    p.kill()
                break
            if on_poll:
                on_poll()
            time.sleep(0.5)
        p.wait()
    try:
        with open(errf, 'rb') as f:
            err = u(f.read()).strip()
        os.remove(errf)
    except Exception:
        err = ''
    return p.returncode, err


# ----------------------------------------------------------------------------
# indice
# ----------------------------------------------------------------------------
def data_path(name):
    return os.path.join(HOME, 'data', name)


def index_age_days():
    ages = []
    for n in ('urls.json', 'ipa.json'):
        p = data_path(n)
        if not os.path.isfile(p):
            return None
        ages.append((time.time() - os.path.getmtime(p)) / 86400.0)
    return max(ages)


def refresh_index(force=False):
    with LOCK:
        if INDEX['busy']:
            return
        INDEX['busy'] = True
    t = threading.Thread(target=_refresh_index, args=(force,))
    t.daemon = True
    t.start()


def _refresh_index(force):
    try:
        if not CFG['curl']:
            INDEX['error'] = 'curl non trovato sull\'iPad: installa "curl" da Cydia'
            return
        d = os.path.join(HOME, 'data')
        if not os.path.isdir(d):
            os.makedirs(d)
        age = index_age_days()
        if age is not None and age < CFG['index_max_age_days'] and not force:
            INDEX['ready'], INDEX['error'] = True, ''
            log('indice in cache (%.1f giorni)' % age)
            return
        INDEX['error'] = ''
        for name in ('urls.json', 'ipa.json'):
            final, tmp = data_path(name), data_path(name) + '.tmp'
            url = CFG['upstream'] + name
            log('scarico %s' % url)

            def poll(tmp=tmp):
                INDEX['bytes'] = os.path.getsize(tmp) if os.path.exists(tmp) else 0
            rc, err = run_curl(url, tmp, on_poll=poll, max_time=900)
            if rc != 0:
                msg = 'download di %s fallito: %s' % (name, curl_error(rc, err))
                log('ERRORE: ' + msg)
                if os.path.isfile(final):
                    log('uso la copia vecchia di %s' % name)
                    continue
                INDEX['error'] = msg
                return
            try:
                with open(tmp, 'rb') as f:
                    json.loads(u(f.read()))
            except Exception as e:
                INDEX['error'] = '%s scaricato ma non e JSON valido (%r)' % (name, e)
                log('ERRORE: ' + INDEX['error'])
                os.remove(tmp)
                return
            replace(tmp, final)
            INDEX['bytes'] = os.path.getsize(final)
            log('%s ok (%s)' % (name, human(os.path.getsize(final))))
        INDEX['ready'], INDEX['error'] = True, ''
    except Exception as e:
        INDEX['error'] = 'errore interno: %r' % (e,)
        log(traceback.format_exc())
    finally:
        INDEX['busy'] = False


_URLS = {'mtime': None, 'data': {}}


def base_urls():
    p = data_path('urls.json')
    m = os.path.getmtime(p)
    if _URLS['mtime'] != m:
        with open(p, 'rb') as f:
            _URLS['data'] = json.loads(u(f.read()))
        _URLS['mtime'] = m
    return _URLS['data']


def lookup(pk):
    """Trova la riga con quel numero senza caricare tutto l'indice in memoria."""
    with open(data_path('ipa.json'), 'rb') as f:
        text = u(f.read())
    dec = json.JSONDecoder()
    for m in re.finditer(r'\[\s*%d\s*,' % pk, text):
        try:
            row, _ = dec.raw_decode(text, m.start())
        except ValueError:
            continue
        if isinstance(row, list) and len(row) >= 9 and row[0] == pk:
            return row
    return None


# ----------------------------------------------------------------------------
# lavori di installazione
# ----------------------------------------------------------------------------
def public(job):
    return dict((k, job[k]) for k in ('pk', 'title', 'state', 'msg', 'bytes', 'total', 'started', 'finished'))


def set_job(job, **kw):
    with LOCK:
        job.update(kw)


def enqueue(pk):
    with LOCK:
        old = JOBS.get(pk)
        if old and old['state'] in ('queued', 'downloading', 'installing'):
            return old, False
        job = {'pk': pk, 'title': '#%d' % pk, 'state': 'queued', 'msg': 'In coda', 'bytes': 0, 'total': 0,
               'started': time.time(), 'finished': None, 'cancel': False}
        JOBS[pk] = job
    QUEUE.put(pk)
    log('job %d in coda' % pk)
    return job, True


def run_job(job):
    pk = job['pk']
    cancelled = lambda: job['cancel']
    if not CFG['curl']:
        return fail(job, 'curl non trovato: installa "curl" da Cydia')
    if not CFG['installer']:
        return fail(job, 'nessun installer trovato: installa "IPA Installer Console" (ipainstaller) o appinst da Cydia')
    if not INDEX['ready']:
        return fail(job, 'indice non ancora pronto')
    row = lookup(pk)
    if not row:
        return fail(job, 'app %d non presente nell\'indice' % pk)
    base = T(base_urls().get(T(row[6]), ''))
    if not base.startswith('http'):
        return fail(job, 'sorgente %s non valida per questa app' % row[6])
    url = base.rstrip('/') + '/' + encode_path(T(row[7]))
    title = u(row[3] or '?')
    expect = int(row[8] or 0) * 1024
    set_job(job, title=title, state='downloading', msg='Preparo il download', total=expect)
    log('job %d: %s -> %s' % (pk, title, url))

    free = free_bytes(HOME)
    need = int(expect * 2.5) + 200 * 1048576
    if free < need:
        return fail(job, 'spazio insufficiente: liberi %s, servono circa %s (scaricamento + installazione)' % (human(free), human(need)))

    dl = os.path.join(HOME, 'downloads')
    if not os.path.isdir(dl):
        os.makedirs(dl)
    safe = re.sub(r'[^A-Za-z0-9._-]', '_', title)[:60] or 'app'
    final = os.path.join(dl, '%d_%s.ipa' % (pk, safe))
    part = final + '.part'

    # dimensione reale (HEAD) per una percentuale esatta
    try:
        out = u(subprocess.Popen(curl_cmd(url, head=True, timeout=30), stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0])
        lens = re.findall(r'(?im)^content-length:\s*(\d+)', out)
        if lens and int(lens[-1]) > 0:
            set_job(job, total=int(lens[-1]))
    except Exception as e:
        log('job %d: HEAD fallito (%r), uso la dimensione dell\'indice' % (pk, e))

    def poll():
        sz = os.path.getsize(part) if os.path.exists(part) else 0
        set_job(job, bytes=sz, msg='Scarico' if sz else 'Mi collego ad archive.org')

    reset_done = False
    for attempt in range(1, 5):
        rc, err = run_curl(url, part, resume=True, on_poll=poll, cancelled=cancelled)
        if job['cancel']:
            return finish(job, 'cancelled', 'Annullato')
        if rc == 0:
            break
        if rc == 33 and not reset_done:  # server senza Range: ricomincia da zero
            log('job %d: ripresa non supportata, riparto da zero' % pk)
            reset_done = True
            try:
                os.remove(part)
            except OSError:
                pass
            continue
        if rc in (18, 52, 55, 56, 28, 7, 6) and attempt < 4:  # rete instabile: riprendi
            log('job %d: curl rc=%d (%s), riprendo (tentativo %d/4)' % (pk, rc, err[:80], attempt + 1))
            set_job(job, msg='Connessione instabile, riprendo...')
            time.sleep(2 * attempt)
            continue
        break
    if rc != 0:
        log('job %d: curl rc=%d err=%s' % (pk, rc, err))
        return fail(job, curl_error(rc, err))
    size = os.path.getsize(part)
    if job['total'] and size != job['total'] and abs(size - job['total']) > 4096 and size < job['total']:
        return fail(job, 'download incompleto (%s di %s): riprova, riprendera da dove era arrivato' % (human(size), human(job['total'])))
    if not zipfile.is_zipfile(part):
        os.remove(part)
        return fail(job, 'il file scaricato non e una IPA valida (non e uno zip)')
    replace(part, final)
    set_job(job, bytes=size, total=size, state='installing', msg='Installo con %s' % os.path.basename(CFG['installer']))
    cmd = [CFG['installer']] + list(CFG['installer_args']) + [final]
    log('job %d: %s' % (pk, ' '.join(cmd)))
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = u(p.communicate()[0])
        rc = p.returncode
    except Exception as e:
        return fail(job, 'impossibile avviare l\'installer: %r' % (e,))
    log('job %d: installer rc=%d output:\n%s' % (pk, rc, out.strip()[-1500:]))
    bad = re.search(r'\b(fail|failed|error|unable|cannot|denied)\b', out, re.I)
    if rc != 0 or bad:
        last = [l for l in out.strip().splitlines() if l.strip()][-1:] or ['nessun messaggio']
        return fail(job, 'installazione non riuscita (codice %d): %s' % (rc, last[0][:160]))
    if not CFG['keep_ipa']:
        try:
            os.remove(final)
        except OSError:
            pass
    uic = which('uicache')
    if uic:
        try:
            subprocess.Popen([uic], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
        except Exception as e:
            log('uicache fallita: %r' % (e,))
    finish(job, 'done', 'Installata')
    log('job %d: COMPLETATO (%s)' % (pk, title))


def finish(job, state, msg):
    set_job(job, state=state, msg=msg, finished=time.time())


def fail(job, msg):
    log('job %d: ERRORE: %s' % (job['pk'], msg))
    finish(job, 'error', msg)


def worker():
    while True:
        pk = QUEUE.get()
        job = JOBS.get(pk)
        if not job or job['cancel']:
            if job:
                finish(job, 'cancelled', 'Annullato')
            continue
        try:
            run_job(job)
        except Exception as e:
            log(traceback.format_exc())
            fail(job, 'errore interno: %r' % (e,))


# ----------------------------------------------------------------------------
# HTTP
# ----------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = 'IPABrowserd/' + VERSION

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype='application/json', extra=None):
        body = b(body)
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-cache')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj))

    def _err(self, code, msg):
        self._json(code, {'error': msg})

    def _host_ok(self):
        host = (self.headers.get('Host') or '').lower()
        if CFG['bind'] in ('127.0.0.1', 'localhost'):
            return host in ('127.0.0.1:%d' % CFG['port'], 'localhost:%d' % CFG['port'])
        return bool(host)

    def _origin_ok(self):
        o = self.headers.get('Origin')
        if not o:
            return True
        return urlsplit(o).netloc.lower() == (self.headers.get('Host') or '').lower()

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            if not self._host_ok():
                log('RIFIUTATO Host non valido: %r' % self.headers.get('Host'))
                return self._err(403, 'host non consentito')
            path = urlsplit(self.path).path
            if path in ('/', '/index.html'):
                p = os.path.join(CFG['www'], 'index.html')
                if not os.path.isfile(p):
                    return self._err(404, 'index.html mancante in %s' % CFG['www'])
                with open(p, 'rb') as f:
                    return self._send(200, f.read(), 'text/html; charset=utf-8')
            if path in ('/data/urls.json', '/data/ipa.json'):
                p = data_path(path.rsplit('/', 1)[1])
                if not INDEX['ready'] or not os.path.isfile(p):
                    return self._err(503, 'indice non pronto')
                with open(p, 'rb') as f:
                    return self._send(200, f.read())
            m = re.match(r'^/img/(\d+)\.jpg$', path)
            if m:
                return self.icon(int(m.group(1)))
            if path == '/api/status':
                return self._json(200, status())
            if path == '/api/jobs':
                with LOCK:
                    return self._json(200, [public(j) for j in JOBS.values()])
            if path == '/api/log':
                p = os.path.join(HOME, 'ipabrowser.log')
                txt = ''
                if os.path.isfile(p):
                    with open(p, 'rb') as f:
                        f.seek(max(0, os.path.getsize(p) - 30000))
                        txt = u(f.read())
                return self._send(200, '\n'.join(txt.splitlines()[-250:]) + '\n', 'text/plain; charset=utf-8')
            if path == '/ping':
                return self._send(200, 'ok\n', 'text/plain')
            return self._err(404, 'non trovato')
        except (IOError, OSError) as e:
            log('connessione interrotta su %s: %r' % (self.path[:60], e))
        except Exception as e:
            log(traceback.format_exc())
            try:
                self._err(500, 'errore interno: %r' % (e,))
            except Exception:
                pass

    def do_POST(self):
        try:
            if not self._host_ok() or not self._origin_ok():
                log('RIFIUTATO POST: Host=%r Origin=%r' % (self.headers.get('Host'), self.headers.get('Origin')))
                return self._err(403, 'richiesta non consentita')
            if self.headers.get('X-IPAB') != '1':
                log('RIFIUTATO POST senza X-IPAB')
                return self._err(403, 'intestazione X-IPAB mancante')
            n = int(self.headers.get('Content-Length') or 0)
            if n > 4096:
                return self._err(413, 'corpo troppo grande')
            body = {}
            if n:
                try:
                    body = json.loads(u(self.rfile.read(n)))
                except ValueError:
                    return self._err(400, 'JSON non valido')
            path = urlsplit(self.path).path
            if path == '/api/refresh':
                INDEX['ready'] = False
                refresh_index(force=True)
                return self._json(200, {'ok': True})
            pk = body.get('pk') if isinstance(body, dict) else None
            if isinstance(pk, bool) or not isinstance(pk, int) or pk < 0 or pk > 10 ** 9:
                return self._err(400, 'pk non valido')
            if path == '/api/install':
                if not INDEX['ready']:
                    return self._err(503, 'indice non pronto')
                job, new = enqueue(pk)
                return self._json(200, {'job': public(job), 'new': new})
            if path == '/api/cancel':
                job = JOBS.get(pk)
                if job:
                    job['cancel'] = True
                    log('job %d: annullamento richiesto' % pk)
                return self._json(200, {'ok': True})
            if path == '/api/dismiss':
                with LOCK:
                    j = JOBS.get(pk)
                    if j and j['state'] in ('done', 'error', 'cancelled'):
                        del JOBS[pk]
                return self._json(200, {'ok': True})
            return self._err(404, 'non trovato')
        except Exception as e:
            log(traceback.format_exc())
            try:
                self._err(500, 'errore interno: %r' % (e,))
            except Exception:
                pass

    def icon(self, pk):
        p = os.path.join(HOME, 'data', 'img', str(pk // 1000), '%d.jpg' % pk)
        if not os.path.isfile(p):
            if pk in NOICON or not CFG['curl']:
                return self._err(404, 'icona non disponibile')
            ICON_SLOTS.acquire()
            try:
                if not os.path.isfile(p):
                    d = os.path.dirname(p)
                    if not os.path.isdir(d):
                        try:
                            os.makedirs(d)
                        except OSError:
                            pass
                    tmp = '%s.%d.tmp' % (p, threading.current_thread().ident)
                    rc, err = run_curl('%s%d/%d.jpg' % (CFG['upstream'], pk // 1000, pk), tmp, max_time=40)
                    if rc != 0 or not os.path.exists(tmp):
                        NOICON.add(pk)
                        for x in (tmp, tmp + '.err'):
                            if os.path.exists(x):
                                os.remove(x)
                        return self._err(404, 'icona non disponibile')
                    replace(tmp, p)
            finally:
                ICON_SLOTS.release()
        with open(p, 'rb') as f:
            self._send(200, f.read(), 'image/jpeg', {'Cache-Control': 'max-age=86400'})


class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def status():
    age = index_age_days()
    return {
        'mode': 'device', 'version': VERSION, 'python': sys.version.split()[0],
        'curl': CFG['curl'] or None, 'installer': CFG['installer'] or None,
        'index_ready': INDEX['ready'], 'index_bytes': INDEX['bytes'], 'index_error': INDEX['error'],
        'index_busy': INDEX['busy'], 'index_age_days': age,
        'free_mb': int(free_bytes(HOME) / 1048576), 'home': HOME, 'upstream': CFG['upstream'],
    }


def main():
    load_config()
    log('=== IPA Browser servizio %s, Python %s ===' % (VERSION, sys.version.split()[0]))
    log('HOME=%s curl=%s installer=%s' % (HOME, CFG['curl'] or 'NON TROVATO', CFG['installer'] or 'NON TROVATO'))
    if not os.path.isdir(HOME):
        os.makedirs(HOME)
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()
    refresh_index()
    srv = Server((CFG['bind'], CFG['port']), Handler)
    log('PRONTO su http://%s:%d/' % (CFG['bind'], CFG['port']))

    def stop(*_):
        log('arresto richiesto')
        threading.Thread(target=srv.shutdown).start()
    try:
        signal.signal(signal.SIGTERM, stop)
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    srv.server_close()
    log('fermato')


if __name__ == '__main__':
    main()
